# Miners-haven-New-Heights
This is the Miner's Haven open source BUT with working Hydraulics And Platforms!

Latest(New/Way Less Buggy): MinersHavenNewHeightsWorkingV6.rbxl

Legacy (Old/Buggy): MinersHavenNewHeightsWorkingV2.rbxl

MinersHavenNewHeightsWorkingV4.rbxl and newer has got support for you to just copy and paste your current modded haven games (if you already have one) to just replace the items folder in this open source with your current (if you have one) modded haven items!

You can also start a new modded haven with this!

Youtube tutorial on how to change platform costs and more: https://www.youtube.com/playlist?list=PLWSkl7e2lb8KPUIArxrblPumX2qC0bIHh

You do have to make item icons for the platforms and hydraulics!
